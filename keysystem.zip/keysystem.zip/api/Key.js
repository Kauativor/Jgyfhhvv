// api/key.js
export default function handler(req, res) {
  const { action, key } = req.query;

  // Simples "banco de dados" na memória (em produção use Redis ou DB real)
  const keys = {};

  // Gerar Key (expira em 24h)
  if (action === "getkey") {
    const newKey = Math.random().toString(36).substring(2, 10).toUpperCase();
    const expires = Date.now() + 24 * 60 * 60 * 1000; // 24h
    keys[newKey] = expires;
    return res.status(200).json({ key: newKey, expires });
  }

  // Verificar Key
  if (action === "verify") {
    if (keys[key] && keys[key] > Date.now()) {
      return res.status(200).json({ status: "VALID" });
    } else {
      return res.status(200).json({ status: "INVALID" });
    }
  }

  return res.status(400).json({ error: "Invalid action" });
}